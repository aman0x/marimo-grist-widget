"""
Keyward API - Simplified interface for data table operations
"""
import pandas as pd
from typing import Any, Dict, List, Optional, Union
from .table_operations import (
    create_table, remove_table, add_data, delete_data, update_table,
    change_column_type, rename_table, remove_column, replace_table_data,
    modify_column, update_record, update_records, fetch_table_to_dataframe,
    create_table_from_dataframe, merge_tables, merge_tables_strict,
    list_tables, get_doc_id, get_access_token, set_debug, enable_debug,
    AsyncDataFramePipeline, AsyncPipeline, _get_grist_api, _resolve_table_name
)


class KeywardApi:
    def __init__(self):
        self.connected = True
        # Check if we have data API available
        try:
            import sys
            if 'grist' in sys.modules:
                self.has_data_api = True
                self.data_module = sys.modules['grist']
            else:
                self.has_data_api = False
                self.data_module = None
        except Exception:
            print("Warning: Data API not available")
            self.has_data_api = False
            self.data_module = None

    async def create_table(self, table_name: str, columns: Dict[str, str]) -> bool:
        """Create a table with specified columns"""
        return await create_table(table_name, columns)

    async def add_record(self, table_name: str, record: Dict[str, Any]) -> Optional[List[int]]:
        """Add a single record to a table"""
        return await add_data(table_name, [record])

    async def add_records(self, table_name: str, records: List[Dict[str, Any]]) -> Optional[List[int]]:
        """Add multiple records to a table"""
        return await add_data(table_name, records)
    
    async def bulk_add_records(self, table_name: str, records: List[Dict[str, Any]]) -> Optional[List[int]]:
        """Bulk add multiple records to a table (alias for add_records)"""
        return await self.add_data(table_name, records)

    async def get_table(self, table_name: str) -> pd.DataFrame:
        """Get table data as a DataFrame"""
        return await fetch_table_to_dataframe(table_name)

    async def update_record(self, table_name: str, record_id: int, updates: Dict[str, Any]) -> bool:
        """Update a record in a table"""
        return await update_record(table_name, record_id, updates)

    async def delete_record(self, table_name: str, record_id: int) -> bool:
        """Delete a record from a table"""
        return await delete_data(table_name, row_ids=[record_id])

    async def create_from_dataframe(self, table_name: str, dataframe: pd.DataFrame) -> Optional[str]:
        """Create a table from a pandas DataFrame"""
        return await create_table_from_dataframe(table_name, dataframe)

    async def bulk_update_records(self, table_name: str, updates: List[Dict[str, Any]]) -> List[bool]:
        """Update multiple records at once"""
        return await self.update_records(table_name, updates)

    async def bulk_delete_records(self, table_name: str, record_ids: List[int]) -> bool:
        """Delete multiple records at once"""
        return await self.delete_data(table_name, row_ids=record_ids)
    
    async def add_data(self, table_name: str, records: List[Dict[str, Any]]) -> Optional[List[int]]:
        """Add data to a table (direct wrapper for add_data)"""
        return await add_data(table_name, records)
    
    async def delete_data(self, table_name: str, row_ids: Optional[List[int]] = None, where: Optional[Dict[str, Any]] = None) -> bool:
        """Delete data from a table with row_ids or where clause"""
        return await delete_data(table_name, row_ids=row_ids, where=where)
    
    async def update_table(self, table_name: str, new_columns: Optional[Dict[str, str]] = None, rename_columns: Optional[Dict[str, str]] = None) -> bool:
        """Update table structure by adding or renaming columns"""
        return await update_table(table_name, new_columns=new_columns, rename_columns=rename_columns)
    
    async def change_column_type(self, table_name: str, col_id: str, new_type: str, label: Optional[str] = None) -> bool:
        """Change the type of a column"""
        return await change_column_type(table_name, col_id, new_type, label=label)
    
    async def remove_column(self, table_name: str, col_id: str) -> bool:
        """Remove a column from a table"""
        return await remove_column(table_name, col_id)
    
    async def replace_table_data(self, table_name: str, bulk_values: List[Dict[str, Any]]) -> bool:
        """Replace all data in a table"""
        # Convert list of dicts to dict of lists format
        if isinstance(bulk_values, list) and len(bulk_values) > 0:
            columns = set()
            for record in bulk_values:
                columns.update(record.keys())
            
            dict_format = {}
            for col in columns:
                dict_format[col] = [record.get(col, None) for record in bulk_values]
            
            bulk_values = dict_format
        
        return await replace_table_data(table_name, bulk_values)
    
    async def modify_column(self, table_name: str, col_id: str, props: Dict[str, Any]) -> bool:
        """Modify column properties"""
        return await modify_column(table_name, col_id, props)
    
    async def update_records(self, table_name: str, updates: List[Dict[str, Any]]) -> List[bool]:
        """Update multiple records (direct wrapper)"""
        return await update_records(table_name, updates)
    
    async def fetch_table_to_dataframe(self, table_name: str) -> pd.DataFrame:
        """Fetch table data as DataFrame (direct wrapper)"""
        return await fetch_table_to_dataframe(table_name)
    
    async def create_table_from_dataframe(self, table_name: str, df: pd.DataFrame) -> Optional[str]:
        """Create table from DataFrame (direct wrapper)"""
        return await create_table_from_dataframe(table_name, df)
    
    async def merge_tables_strict(self, sources: List[str], target: Optional[str] = None, create_new: bool = False) -> bool:
        """Merge tables with strict schema matching"""
        return await merge_tables_strict(sources, target, create_new)
    
    async def get_doc_id(self) -> Optional[str]:
        """Get the current document ID"""
        return await get_doc_id()
    
    async def get_access_token(self, options: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """Get access token for API access"""
        return await get_access_token(options)
    
    async def bulk_delete_where(self, table_name: str, where: Dict[str, Any]) -> bool:
        """Delete records based on where clause"""
        return await self.delete_data(table_name, row_ids=None, where=where)
    
    async def bulk_merge_tables(self, source_tables: List[str], target_table: Optional[str] = None, create_new: bool = False) -> bool:
        """Bulk merge multiple tables (alias for merge_tables)"""
        return await self.merge_tables(source_tables, target_table, create_new)

    async def get_row_ids(self, table_name: str) -> List[int]:
        """Get row IDs for a table"""
        try:
            # Use the helper function that properly accesses Data API
            from .table_operations import _get_grist_api, _resolve_table_name
            
            # Resolve the actual table name
            actual_table_name = await _resolve_table_name(table_name)
            
            # Get the Data API properly
            grist_api = _get_grist_api()
            data = await grist_api.fetch_table(actual_table_name)
            return data.get('id', [])
        except Exception as e:
            print(f"❌ Error getting row IDs: {e}")
            return []

    async def merge_tables(self, sources: List[str], target: Optional[str] = None, create_new: bool = False) -> bool:
        """Merge tables together"""
        return await merge_tables(sources, target, create_new)

    async def list_tables(self) -> List[str]:
        """List all available tables"""
        return await list_tables()

    async def remove_table(self, table_name: str) -> bool:
        """Remove a table"""
        return await remove_table(table_name)

    async def rename_table(self, old_name: str, new_name: str) -> bool:
        """Rename a table"""
        return await rename_table(old_name, new_name)

    async def get_table_schema(self, table_name: str) -> Dict[str, str]:
        """Get the schema/structure of a table"""
        try:
            # Use the helper function that properly accesses Data API
            from .table_operations import _get_grist_api, _resolve_table_name
            
            # Resolve the actual table name
            actual_table_name = await _resolve_table_name(table_name)
            
            # Get the Data API properly
            grist_api = _get_grist_api()
            data = await grist_api.fetch_table(actual_table_name)
            schema = {}
            
            # Analyze first row if data exists
            if data and any(len(v) > 0 for v in data.values() if v):
                for col, values in data.items():
                    if col in ['id', 'manualSort'] or not values:
                        continue
                    
                    # Find first non-None value
                    sample = next((v for v in values if v is not None), None)
                    if sample is not None:
                        if isinstance(sample, bool):
                            schema[col] = 'Bool'
                        elif isinstance(sample, (int, float)):
                            schema[col] = 'Numeric'
                        else:
                            schema[col] = 'Text'
                    else:
                        schema[col] = 'Text'
            
            return schema
        except Exception as e:
            print(f"❌ Error getting table schema: {e}")
            return {}

    async def query_table(self, table_name: str, filters: Optional[Dict[str, Any]] = None, 
                         columns: Optional[List[str]] = None, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """Query a table with optional filters and column selection"""
        try:
            # Use the helper function that properly accesses Data API
            from .table_operations import _get_grist_api, _resolve_table_name
            
            # Resolve the actual table name
            actual_table_name = await _resolve_table_name(table_name)
            
            # Get the Data API properly
            grist_api = _get_grist_api()
            data = await grist_api.fetch_table(actual_table_name)
            
            # Convert to list of records
            records = []
            row_count = len(data.get('id', []))
            
            for i in range(row_count):
                record = {}
                for col, values in data.items():
                    if col not in ['id', 'manualSort'] and i < len(values):
                        record[col] = values[i]
                records.append(record)
            
            # Apply filters if provided
            if filters:
                filtered_records = []
                for record in records:
                    match = True
                    for col, val in filters.items():
                        if col in record and record[col] != val:
                            match = False
                            break
                    if match:
                        filtered_records.append(record)
                records = filtered_records
            
            # Select specific columns if provided
            if columns:
                records = [{col: r.get(col) for col in columns} for r in records]
            
            # Apply limit if provided
            if limit and limit > 0:
                records = records[:limit]
            
            return records
        except Exception as e:
            print(f"❌ Error querying table: {e}")
            return []

    async def count_records(self, table_name: str, filters: Optional[Dict[str, Any]] = None) -> int:
        """Count records in a table with optional filters"""
        try:
            records = await self.query_table(table_name, filters=filters)
            return len(records)
        except Exception as e:
            print(f"❌ Error counting records: {e}")
            return 0

    # Additional utility methods
    def set_debug(self, enabled: bool):
        """Enable or disable debug logging"""
        set_debug(enabled)
    
    def enable_debug(self):
        """Quick function to enable debug mode with helpful message"""
        enable_debug()

    def create_dataframe_pipeline(self) -> AsyncDataFramePipeline:
        """Create a new AsyncDataFramePipeline"""
        return AsyncDataFramePipeline()

    def create_pipeline(self, initial: Any = None) -> AsyncPipeline:
        """Create a new AsyncPipeline"""
        return AsyncPipeline(initial)

    # Proxy method for direct access to data functions
    def __getattr__(self, name):
        # Try to find method in data module
        if self.data_module and hasattr(self.data_module, name):
            return getattr(self.data_module, name)
        
        # Not found
        raise AttributeError(f"'KeywardApi' has no attribute '{name}'")


# Create a singleton instance
api = KeywardApi()